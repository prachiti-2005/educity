import React from 'react'
import './About.css'
import about_img from '../../assets/about.png'
import play_icon from '../../assets/play-icon.png'



const About = () => {
  return (
    <div className="about">
        <div className="about-left">
            <img src={about_img} alt="" className="about-img" />
            <img src={play_icon} alt="" className="play-icon"/>
        </div>
        <div className="about-right">
            <h3>ABOUT UNIVERSITY</h3>
            <h2>Nurturing Tomorrow's Leaders Today</h2>
            <p>Embark a transformative educational journey with our 
                university's comprehensive education programs. Our cutting-edge
                curriculum is designed to empower students with the knowledge,
                skills, and experiences needed to excel in the dynamic field of 
                education.</p>
            <p>
            Begin a transformative educational journey with our university's innovative programs.
             Our curriculum is thoughtfully designed to provide students with the essential knowledge and practical skills needed to thrive in today's dynamic world. 
             Through a blend of theoretical learning and hands-on experience, we prepare students to excel in their chosen fields.
            </p>
            <p>
                With a focus on cutting-edge advancements, our programs empower students to not only master their subjects but also to lead with confidence in ever-evolving professional environments. Join us and become part of a community dedicated to fostering growth, innovation, and success.
            </p>
        </div>
    </div>
  )
}

export default About