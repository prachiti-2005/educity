import React from 'react'
import Navbar from './Component/Navbar.jsx'
import Hero from './Component/Hero/Hero.jsx'
import Programs from './Component/Programsa/Programs.jsx'
import Title from './Component/Title/Title.jsx'
import About from './Component/About/About.jsx'
import Campus from './Component/Campus/Campus.jsx'
import Testimonials from './Component/Testimonials/Testimonials.jsx'
import ContactUs  from './Component/Contact us/ContactUs.jsx'
import Footer from './Component/Footer/Footer.jsx'



function App(){
  return (
    <div>
        <Navbar/>
        <Hero/>
        <div className="container">
          <Title subTitle='Our Program' title='What We Offer'/>
          <Programs/>
          <About/>
          <Title subTitle='Gallery' title='Campus Photos'/>
          <Campus/>
          <Title subTitle='TESTIMONIALS' title='What Student Says'/>
          <Testimonials/>
          <Title subTitle='Contact Us' title='Get in touch'/>
          <ContactUs/>
          <Footer/>

        </div>
        
    </div>
);
}

export default App
